# Assignment 1 — Text Classification

## 1. Project Overview
This project compares an EmbeddingBag baseline with an LSTM text classifier.

## 2. Main Files
- txt_classifier.py: Training and evaluation code
- task3_1_length_histogram.png: Article length histogram
- logs/: Experiment logs

## 3. Models and Experiments
- EmbeddingBag with SGD
- EmbeddingBag with Adam
- LSTM with Adam
- Different batch sizes and sequence lengths

## 4. Main Results
- EmbeddingBag with Adam: Test accuracy 98.65%
- LSTM with Adam: Test accuracy 94.59%
- EmbeddingBag with SGD, batch size 1, no maximum length: Test accuracy 93.24%

## 5. How to Run

### EmbeddingBag with Adam
python txt_classifier.py --data_dir data --model bag --optimizer adam --batch_size 1 --max_len -1 --n_epochs 5 --seed 42 --output txt_bag_adam_bs1.pth

### LSTM with Adam
python txt_classifier.py --data_dir data --model lstm --optimizer adam --batch_size 1 --max_len -1 --n_epochs 5 --seed 42 --output txt_lstm_adam_bs1.pth

## 6. Trained Checkpoints
Google Drive link: https://drive.google.com/file/d/1Oz_d19EsUUR7olV28UOnrhy4nR-I-1hp/view?usp=sharing

## 7. Report
The assignment report is submitted separately.
